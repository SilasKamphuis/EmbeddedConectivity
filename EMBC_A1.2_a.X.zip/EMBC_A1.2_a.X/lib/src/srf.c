#include <xc.h>
#include <stdlib.h>
#include <sys/attribs.h>
#include <stdio.h>
#include "i2c.h"
#include "timer.h"
#include "srf.h"





void srf_init(int freq) {
 // Provide the implementation
}

void srf_range() {
 // Provide the implementation
    
}
 
unsigned char srf_startRanging() {
 // Provide the implementation
    
    return 1;
}
 
unsigned char srf_getDistance(unsigned short int *distance) {
   // Provide the implementation
    
    return 1;
}
