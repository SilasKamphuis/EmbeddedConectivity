#ifndef _BUTTON_H
#define _BUTTON_H

int debounce (int button);
void init_buttons();

#endif /* _BUTTON_H */